document.getElementById('login-form').addEventListener('submit', function(event) {

    event.preventDefault();

    const email = document.getElementById('email').value;

    const password = document.getElementById('password').value;

    const correctPassword = 'asdfghjkl';

    let balance = 500000;

    if (password === correctPassword) {

        document.body.innerHTML = `

            <div class="dashboard-container">

                <h1>Welcome to Your Bank</h1>

                <div class="account-info">

                    <p>Bank Name: Your Bank</p>

                    <p>Account Number: 87654321</p>

                    <p>Current Balance: N<span id="balance">${balance.toLocaleString()}</span></p>

                </div>

                <div class="actions">

                    <button onclick="addBalance()">Add Money</button>

                    <button onclick="showTransactions()">Transaction History</button>

                    <button onclick="showTransferForm()">Transfer Money</button>

                </div>

                <button onclick="showAboutUs()">About Us</button>

                <div id="dynamic-content"></div>

            </div>

        `;

    } else {

        document.getElementById('error-message').textContent = 'Incorrect password';

    }

});

function addBalance() {

    const amount = prompt('Enter amount to add:');

    if (amount && !isNaN(amount)) {

        const balanceElement = document.getElementById('balance');

        let balance = parseFloat(balanceElement.textContent.replace(/,/g, ''));

        balance += parseFloat(amount);

        balanceElement.textContent = balance.toLocaleString();

    }

}

function showTransactions() {

    const content = document.getElementById('dynamic-content');

    content.innerHTML = `<h2>Transaction History</h2><p>No transactions yet.</p>`;

}

function showTransferForm() {

    const content = document.getElementById('dynamic-content');

    content.innerHTML = `

        <h2>Transfer Money</h2>

        <form id="transfer-form">

            <select id="bank-name" required>

                <option value="">Select Bank</option>

                <option value="Access Bank">Access Bank</option>

                <option value="First Bank">First Bank</option>

                <option value="GTBank">GTBank</option>

                <option value="UBA">UBA</option>

                <option value="Zenith Bank">Zenith Bank</option>

                <option value="Opay">Opay</option>

                <option value="Palmpay">Palmpay</option>

                <!-- Add other banks here -->

            </select>

            <input type="text" id="account-name" placeholder="Account Name" readonly>

            <input type="text" id="account-number" placeholder="Account Number" required>

            <input type="number" id="amount" placeholder="Amount" required>

            <input type="password" id="transfer-password" placeholder="Password" required>

            <button type="submit">Transfer</button>

        </form>

    `;

    // Simulated account number to account name mapping

    const accountNames = {

        "1234567890": "Alice Johnson",

        "0987654321": "Bob Smith",

        "1122334455": "Charlie Brown"

        // Add more mappings as needed

    };

    document.getElementById('account-number').addEventListener('input', function() {

        const accountNumber = document.getElementById('account-number').value;

        const accountName = accountNames[accountNumber] || '';

        document.getElementById('account-name').value = accountName;

    });

    document.getElementById('transfer-form').addEventListener('submit', function(event) {

        event.preventDefault();

        const amount = parseFloat(document.getElementById('amount').value);

        const password = document.getElementById('transfer-password').value;

        if (password === 'asdfghjkl') {

            const balanceElement = document.getElementById('balance');

            let balance = parseFloat(balanceElement.textContent.replace(/,/g, ''));

            if (amount <= balance) {

                balance -= amount;

                balanceElement.textContent = balance.toLocaleString();

                alert('Transfer successful');

            } else {

                alert('Insufficient balance');

            }

        } else {

            alert('Incorrect password');

        }

    });

}

function showAboutUs() {

    const content = document.getElementById('dynamic-content');

    content.innerHTML = `

        <h2>About Us</h2>

        <p>This is a fake transfer app that allows you to transfer unlimited fake money.</p>

    `;

}